<ul class="menu" id="topmenu">
	<li><div class="bg"><a href="">Penerimaan</a></div></li>
	<li><div class="bg"><a href="">Kemahasiswaan</a></div></li>
	<li><div class="bg"><a href="">Alumni</a></div></li>
	<li class="par">
		<div class="bg"><span>Akses Cepat</span><i class="fas fa-angle-down ico on"></i></div>
		<div class="chi">
			<div class="max">
				<ul>
					<li><div class="bg"><a href="">SIAK</a></div></li>
					<li><div class="bg"><a href="">SIPEG</a></div></li>
					<li><div class="bg"><a href="">E-MAS</a></div></li>
					<li><div class="bg"><a href="">EDOM</a></div></li>
					<li><div class="bg"><a href="">SIRIP</a></div></li>
					<li><div class="bg"><a href="">Mobilitas</a></div></li>
					<li><div class="bg"><a href="">Bimbingan & Sidang</a></div></li>
					<li><div class="bg"><a href="">Ruangan</a></div></li>
				</ul>
			</div>
		</div>
	</li>
	<li class="par">
		<div class="bg"><span>Sistem Informasi</span><i class="fas fa-angle-down ico on"></i></div>
		<div class="chi">
			<div class="max">
				<ul>
					<li><div class="bg"><a href="">SIAK</a></div></li>
					<li><div class="bg"><a href="">SIPEG</a></div></li>
					<li><div class="bg"><a href="">E-MAS</a></div></li>
					<li><div class="bg"><a href="">EDOM</a></div></li>
					<li><div class="bg"><a href="">SIRIP</a></div></li>
					<li><div class="bg"><a href="">Mobilitas</a></div></li>
					<li><div class="bg"><a href="">Bimbingan & Sidang</a></div></li>
					<li><div class="bg"><a href="">Ruangan</a></div></li>
					<li><div class="bg"><a href="">Lembaga Konsultasi, Bantuan Hukum dan Pilihan Penyelesaian Sengketa</a></div></li>
				</ul>
			</div>
		</div>
	</li>
</ul>
