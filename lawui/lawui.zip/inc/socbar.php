<div id="socbar">
	<ul>
		<li class="soc"><a href=""><i class="fab fa-facebook-f"></i></a></li>
		<li class="soc"><a href=""><i class="fab fa-twitter"></i></a></li>
		<li class="soc"><a href=""><i class="fab fa-instagram"></i></a></li>
		<li class="soc"><a href=""><i class="fab fa-youtube"></i></a></li>
		<li id="lang"><a href=""><span>English</span></a></li>
	</ul>
</div>
