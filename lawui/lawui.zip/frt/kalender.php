<div class="frt agenda frt-agenda" id="frt-kalender">
	<h1><a href="">Kalender Akademik</a></h1>
	<div class="flx">

		<div class="item">
			<div class="pad">
				<div class="tglbox">
					<div class="tgl tgl-1">
						<span class="dat">22</span>
						<span class="mth">Sep</span>
					</div>
					<div class="tgl tgl-2">
						<span class="dat">24</span>
						<span class="mth">Sep</span>
					</div>
				</div>
				<div class="cnt">
					<h2>Masa Orientasi Mahasiswa Baru</h2>
					<div class="location"><i class="fas fa-user"></i> Program Sarjana</div>
				</div>
			</div>
			<a href="#"></a>
		</div>

		<div class="item">
			<div class="pad">
				<div class="tglbox">
					<div class="tgl tgl-1">
						<span class="dat">15</span>
						<span class="mth">Agu</span>
					</div>
					<div class="tgl tgl-2">
						<span class="dat">24</span>
						<span class="mth">Sep</span>
					</div>
				</div>
				<div class="cnt">
					<h2>Registrasi Mata Kuliah</h2>
					<div class="location"><i class="fas fa-user"></i> Mahasiswa Baru Program Sarjana</div>
				</div>
			</div>
			<a href="#"></a>
		</div>

		<div class="item">
			<div class="pad">
				<div class="tglbox">
					<div class="tgl tgl-1">
						<span class="dat">15</span>
						<span class="mth">Agu</span>
					</div>
					<div class="tgl tgl-2">
						<span class="dat">22</span>
						<span class="mth">Sep</span>
					</div>
				</div>
				<div class="cnt">
					<h2>Registrasi Mata Kuliah</h2>
					<div class="location"><i class="fas fa-user"></i> Mahasiswa Lama Semua Program</div>
				</div>
			</div>
			<a href="#"></a>
		</div>

	</div>
</div>
