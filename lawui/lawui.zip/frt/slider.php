<div class="slickbox frt slider box" id="box-slider">
	<div class="big shd top"></div>
	<div class="slick" id="slick-slider">
		<div class="item">
			<img height="auto" width="100%" src="img/banner/1.jpg" alt="Banner 1">
			<span class="base btm rgt opq">
				<span class="text">
					<span class="h1"><span style="background:#a00;color:#fff;">Header Pertama</span></span>
					<span class="h2"><span style="color:#fff;">Subheader pertama lorem ipsum dolor sit amet consectuer adiplicing elit.</span></span>
				</span>
			</span>
		</div>
		<a class="item" href="">
			<img height="auto" width="100%" src="img/banner/red.jpg" alt="Banner 2">
			<span class="base btm ctr opq">
				<span class="text">
					<span class="h1"><span style="background:#a00;color:#fff;">Header Kedua</span></span>
					<span class="h2"><span style="background:#fd0;color:#000;">Subheader kedua lorem ipsum dolor sit amet consectuer adiplicing elit.</span></span>
				</span>
			</span>
		</a>
		<a class="item" href="">
			<img height="auto" width="100%" src="img/banner/blue2.jpg" alt="Banner 3">
			<span class="base mid ctr">
				<span class="text">
					<span class="h1"><span style="color:#fd0;">Header Kedua Lorem Ipsum Dolor sit Amet Consectuer Adiplicing Elit</span></span>
				</span>
			</span>
		</a>
		<div class="item">
			<img height="auto" width="100%" src="img/banner/blue.jpg" alt="Banner 4">
			<span class="base mid lft">
				<span class="text">
					<span class="h1"><span style="color:#fd0;">Header Kedua</span></span>
					<span class="h2"><span style="color:#fff;">Subheader kedua lorem ipsum dolor sit amet consectuer adiplicing elit.</span></span>
				</span>
			</span>
		</div>
	</div>
</div>