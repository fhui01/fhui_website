<div class="frt pengumuman box" id="box-pengumuman">
	<i class="ico fas fa-angle-left"></i>
	<i class="ico fas fa-angle-down"></i>
	<span class="ico">Pengumuman<i class="fas fa-angle-right"></i>	<i class="ico fas fa-angle-up"></i></span>
	<div class="box">
		<h1><a href="">Pengumuman</a></h1>
		<!--div class="item 1">
			<div class="base">
				<div class="tglbox">
					<div class="tgl tgl-1">
						<span class="dat">15</span>
						<span class="mth">Jan</span>
					</div>
					<div class="tgl tgl-2">
						<span class="dat">17</span>
						<span class="mth">Jan</span>
					</div>
				</div>
				<div class="cnt">
					<h2><a href="">Pembukaan Pendaftaran Pelatihan Khusus Profesi Advokat Periode 4 Tahun 2020.</a></h2>
				</div>
			</div>
		</div>
		<div class="item 2">
			<div class="base">
				<div class="tglbox">
					<div class="tgl tgl-1">
						<span class="dat">24</span>
						<span class="mth">Sep</span>
					</div>
				</div>
				<div class="cnt">
					<h2><a href="">Hasil Seleksi Ujian Masuk Kursus Pengembangan Keterampilan dan Keahlian dalam rangka Sertifikasi Kompetensi Pegawai Lorem Ipsum Dolor sit Amet Consectuer Adiplicing Elit Lipsum Dolor sit Amet Lorem Ipsum Dolor.</a></h2>
				</div>
			</div>
		</div-->
		<div class="item 3">
			<div class="base">
				<div class="tglbox">
					<div class="tgl tgl-1">
						<span class="dat">20</span>
						<span class="mth">Mei</span>
					</div>
					<div class="tgl tgl-2">
						<span class="dat">30</span>
						<span class="mth">Mei</span>
					</div>
				</div>
				<div class="cnt">
					<h2><a href="">Tender Pengadaan Barang Voucher Belanja FHUI Tahun 2020</a></h2>
				</div>
			</div>
		</div>
	</div>
</div>
