<div class="frt dekan frt-dekan" id="frt-dekan">
	<h1><a href="">Dari Meja Dekan</a></h1>
	<div class="flx">
		<img src="img/dekan.jpg">
		<h2><a href="">Selamat Datang Mahasiswa Baru 2020!</a></h2>
	</div>
</div>
<div class="frt media frt-media" id="frt-media">
	<h1><a href="">Dalam Media</a></h1>
	<h2><a href=""><span>Detikcom, 15 Feb 2020 </span>Lorem Ipsum Dolor sit Amet Consectuer Adiplicing Elit</a></h2>
	<h2><a href=""><span>Kompas.com, 17 Mar 2020 </span>Prof. Hikmahanto Juwana: Lorem Ipsum Dolor sit Amet Consectuer Adiplicing Elit</a></h2>
	<h2><a href=""><span>Tempo.co, 24 Jun 2020 </span>How to Create a Responsive Square with CSS</a></h2>
</div>
<div class="frt video frt-video" id="frt-video">
	<a class="ytb" href="" target="_blank">
		<span class="ytb-img">
			<img src="http://i1.ytimg.com/vi/i8k0v4Widvc/3.jpg">
			<i class="fas fa-play"></i>
		</span>
		<span class="ytb-txt">Video Profil FHUI</span>
	</a>
</div>
