<div class="frt agenda frt-agenda" id="frt-agenda">
	<h1><a href="">Agenda</a></h1>
	<div class="flx">

		<div class="item">
			<div class="pad">
				<div class="tglbox">
					<div class="tgl tgl-2">
						<span class="dat">24</span>
						<span class="mth">Sep</span>
					</div>
				</div>
				<div class="cnt">
					<h2>Promosi Doktor Ilmu Hukum Sophia Lorentz</h2>
					<div class="location"><i class="fas fa-map-marker-alt"></i> Balai Sidang Djokosoetono, FHUI Depok</div>
				</div>
			</div>
			<a href="#"></a>
		</div>

		<div class="item">
			<div class="pad">
				<div class="tglbox">
					<div class="tgl tgl-1">
						<span class="dat">22</span>
						<span class="mth">Sep</span>
					</div>
					<div class="tgl tgl-2">
						<span class="dat">24</span>
						<span class="mth">Sep</span>
					</div>
				</div>
				<div class="cnt">
					<h2>Ujian Masuk Program Magang Riset Online</h2>
					<div class="location"><i class="fas fa-map-marker-alt"></i> Ruang Soemadipradja dan Taher, FHUI Depok</div>
				</div>
			</div>
			<a href="#"></a>
		</div>

		<div class="item">
			<div class="pad">
				<div class="tglbox">
					<div class="tgl tgl-2">
						<span class="dat">24</span>
						<span class="mth">Sep</span>
					</div>
				</div>
				<div class="cnt">
					<h2>Promosi Doktor Ilmu Hukum Sophia Lorentz</h2>
					<div class="location"><i class="fas fa-map-marker-alt"></i> Balai Sidang Djokosoetono, FHUI Depok</div>
				</div>
			</div>
			<a href="#"></a>
		</div>

		<div class="item">
			<div class="pad">
				<div class="tglbox">
					<div class="tgl tgl-1">
						<span class="dat">22</span>
						<span class="mth">Sep</span>
					</div>
					<div class="tgl tgl-2">
						<span class="dat">24</span>
						<span class="mth">Sep</span>
					</div>
				</div>
				<div class="cnt">
					<h2>Ujian Masuk Program Magang Riset Online</h2>
					<div class="location"><i class="fas fa-map-marker-alt"></i> Ruang Soemadipradja dan Taher, FHUI Depok</div>
				</div>
			</div>
			<a href="#"></a>
		</div>

		<div class="item">
			<div class="pad">
				<div class="tglbox">
					<div class="tgl tgl-2">
						<span class="dat">24</span>
						<span class="mth">Sep</span>
					</div>
				</div>
				<div class="cnt">
					<h2>Webinar Bidang Studi Hukum Islam dan Hukum Adat Seri 1: "Tindak Pidana Teknologi Finansial Syariah di Indonesia"</h2>
					<div class="location"><i class="fas fa-map-marker-alt"></i> Zoom Webinar</div>
				</div>
			</div>
			<a href="#"></a>
		</div>

	</div>
</div>
