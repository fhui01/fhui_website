<div class="frt memoriam box" id="box-memoriam">
	<h1><a href="">Berita Duka</a></h1>
	<div class="item">
		<div class="max">
			<div class="img"><img src="img/mirna.jpg" alt="Mirna Adriani"></div>
			<div class="cnt">
				<h2>
					<a href="">Mirna Adriani, Ph.D.</a>
					<span>Dekan Fakultas Ilmu Komputer Universitas Indonesia</span>
				</h2>
				<div class="rip-tgl">12 Maret 1972 - 15 Juli 2020</div>
				<p>Telah berpulang ke hadirat Tuhan, YME, Dekan Fakultas Ilmu Komputer, Universitas Indonesia pada hari Rabu, 15 Juli 2020 pukul 05:00 WIB. Segenap sivitas akademika Fakultas Hukum Universitas Indonesia (FHUI) turut berduka cita yang sedalam-dalamnya atas wafatnya beliau.</p>
			</div>
		</div>
	</div>
	<!--div class="item">
		<div class="max">
			<div class="img"><img src="img/roselani.jpg" alt="Mirna Adriani"></div>
			<div class="cnt">
				<h2>
					<a href="">drg. Roselani Widajati L., MDSc., Sp.Pros(K)</a>
					<span>Pengajar Fakultas Kedokteran Gigi Universitas Indonesia</span>
				</h2>
				<div class="rip-tgl">2 April 2020</div>
				<p>Telah meninggal dunia drg. Roselani Widajati L., MDSc., Sp.Pros(K) binti A.N. Luddin, staf pengajar Departemen Prostodonsia, Fakultas Kedokteran Gigi, Universitas Indonesia pada hari Kamis, 2 April 2020 pukul 09.14 WIB dalam usia 66 tahun. Segenap sivitas akademika Fakultas Hukum Universitas Indonesia (FHUI) turut berduka cita yang sedalam-dalamnya atas wafatnya beliau.</p>
			</div>
		</div>
	</div-->
</div>
