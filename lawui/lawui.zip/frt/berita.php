<div class="frt berita frt-berita" id="frt-berita">
	<h1><a href="">Berita</a></h1>
	<div class="flx">
	
		<div class="item">
			<div class="pad">
				<div class="img">
					<img src="img/berita/andhika.jpg" alt="berita 1">
					<i class="fas fa-link"></i>
				</div>
				<h2>Andhika Sudarman, Pemuda Indonesia Pertama yang Terpilih untuk Berpidato di Wisuda Harvard Law School</h2>
				<div class="info">Kamis, 24 September 2020 (Humas FHUI)</div>
				<p>Harvard University dapat dikatakan sebagai cita-cita hampir seluruh mahasiswa di dunia. Setiap tahunnya Harvard Law School menerima hanya sekitar 800 mahasiswa...</p>
			</div>
			<a href=""></a>
		</div>
	
		<div class="item">
			<div class="pad">
				<div class="img">
					<img src="img/berita/andhika.jpg" alt="berita 1">
					<i class="fas fa-link"></i>
				</div>
				<h2>Andhika Sudarman, Pemuda Indonesia Pertama yang Terpilih untuk Berpidato di Wisuda Harvard Law School</h2>
				<div class="info">Kamis, 24 September 2020 (Humas FHUI)</div>
				<p>Harvard University dapat dikatakan sebagai cita-cita hampir seluruh mahasiswa di dunia. Setiap tahunnya Harvard Law School menerima hanya sekitar 800 mahasiswa...</p>
			</div>
			<a href=""></a>
		</div>
	
		<div class="item">
			<div class="pad">
				<div class="img">
					<img src="img/berita/andhika.jpg" alt="berita 1">
					<i class="fas fa-link"></i>
				</div>
				<h2>Andhika Sudarman, Pemuda Indonesia Pertama yang Terpilih untuk Berpidato di Wisuda Harvard Law School</h2>
				<div class="info">Kamis, 24 September 2020 (Humas FHUI)</div>
				<p>Harvard University dapat dikatakan sebagai cita-cita hampir seluruh mahasiswa di dunia. Setiap tahunnya Harvard Law School menerima hanya sekitar 800 mahasiswa...</p>
			</div>
			<a href=""></a>
		</div>
	
		<div class="item">
			<div class="pad">
				<div class="img">
					<img src="img/berita/andhika.jpg" alt="berita 1">
					<i class="fas fa-link"></i>
				</div>
				<h2>Andhika Sudarman, Pemuda Indonesia Pertama yang Terpilih untuk Berpidato di Wisuda Harvard Law School</h2>
				<div class="info">Kamis, 24 September 2020 (Humas FHUI)</div>
				<p>Harvard University dapat dikatakan sebagai cita-cita hampir seluruh mahasiswa di dunia. Setiap tahunnya Harvard Law School menerima hanya sekitar 800 mahasiswa...</p>
			</div>
			<a href=""></a>
		</div>
	
		<div class="item">
			<div class="pad">
				<div class="img">
					<img src="img/berita/andhika.jpg" alt="berita 1">
					<i class="fas fa-link"></i>
				</div>
				<h2>Andhika Sudarman, Pemuda Indonesia Pertama yang Terpilih untuk Berpidato di Wisuda Harvard Law School</h2>
				<div class="info">Kamis, 24 September 2020 (Humas FHUI)</div>
				<p>Harvard University dapat dikatakan sebagai cita-cita hampir seluruh mahasiswa di dunia. Setiap tahunnya Harvard Law School menerima hanya sekitar 800 mahasiswa...</p>
			</div>
			<a href=""></a>
		</div>
	
		<div class="item">
			<div class="pad">
				<div class="img">
					<img src="img/berita/andhika.jpg" alt="berita 1">
					<i class="fas fa-link"></i>
				</div>
				<h2>Andhika Sudarman, Pemuda Indonesia Pertama yang Terpilih untuk Berpidato di Wisuda Harvard Law School</h2>
				<div class="info">Kamis, 24 September 2020 (Humas FHUI)</div>
				<p>Harvard University dapat dikatakan sebagai cita-cita hampir seluruh mahasiswa di dunia. Setiap tahunnya Harvard Law School menerima hanya sekitar 800 mahasiswa...</p>
			</div>
			<a href=""></a>
		</div>
	
	</div>
</div>
